/*
 * ajustes.js — correcciones sobre la aplicación compilada.
 *
 * Responde a dos observaciones del cliente que no se pueden arreglar desde los datos
 * y que tampoco justifican reescribir el bundle:
 *
 *   1. El botón de WhatsApp sólo aparecía en la portada, porque vive dentro del
 *      componente app-home. Aquí se montan dos propios, fijos y en todas las
 *      páginas: ventas y repuestos, cada uno con su número y su etiqueta.
 *
 *   2. «Solicitar cotización» en la ficha de producto llevaba al formulario vacío: el
 *      cliente tenía que volver al catálogo y empezar de nuevo. El formulario ya sabe
 *      rellenarse solo —lo hace cuando el carrito tiene algo, y entonces muestra hasta
 *      la foto—, así que basta con dejar el producto en el carrito antes de navegar.
 *
 *   3. El filtro de marca del catálogo era una lista de 43 radios de 1.251 px sin
 *      buscador: encontrar una marca obligaba a recorrer media página. Se le añade un
 *      buscador, el número de productos de cada marca y una altura máxima con scroll.
 *
 *   4. Los enlaces de Instagram llevaban a una cuenta que no existe y el pie de página
 *      ni siquiera enlazaba. Se apuntan todos al perfil real.
 *
 *   5. Si el archivo del logotipo no llega, el navegador pintaba el icono de imagen
 *      rota. Se prueban los logos de reserva y, si falta todo, se oculta.
 *
 * Se carga como script clásico desde index.html, después de offline-api.js.
 */
(function () {
  'use strict';

  var CLAVE_CARRITO = 'agro_cart';
  var SEL_WA_APP = '.fixed.bottom-8.right-8 a[href*="wa.me"]';

  function raiz() {
    var base = document.querySelector('base');
    return base ? base.getAttribute('href') : '/';
  }

  // --- 1. Botones de WhatsApp en todas las páginas --------------------------
  //
  // Son dos líneas de atención distintas, cada una con su número, así que cada
  // botón lleva su etiqueta: quien busca un repuesto no debería acabar en ventas.
  // Salen de data/settings.json, en `whatsapps`; el primero de la lista es el
  // principal y se dibuja abajo, donde estaba el botón de siempre.
  //
  // Se esconde el botón que trae la aplicación en la portada: si no, allí habría
  // tres. Su globo de «¿Te ayudo a cotizar?» se va con él; la mascota sigue
  // apareciendo en la sección «Nuestra historia».

  var pila = null;
  var numeros = [];

  function icono() {
    return '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true" style="flex:none">' +
      '<path d="M17.47 14.38c-.3-.15-1.75-.86-2.02-.96-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.64.08-.3-.15-1.25-.46-2.38-1.47-.88-.78-1.47-1.75-1.65-2.05-.17-.3-.02-.46.13-.6.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.6-.92-2.2-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.22 3.08c.15.2 2.1 3.2 5.08 4.49.71.3 1.26.49 1.69.63.71.22 1.36.19 1.87.12.57-.09 1.75-.72 2-1.41.25-.69.25-1.28.17-1.41-.07-.13-.27-.2-.57-.35z"/>' +
      '<path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.46 1.32 4.96L2 22l5.25-1.38a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0 0 12.04 2zm0 18.13h-.01a8.23 8.23 0 0 1-4.19-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.2 8.2 0 0 1-1.26-4.36c0-4.54 3.7-8.24 8.25-8.24 2.2 0 4.27.86 5.83 2.42a8.19 8.19 0 0 1 2.41 5.83c0 4.54-3.7 8.21-8.24 8.21z"/></svg>';
  }

  function crearPila() {
    var d = document.createElement('div');
    d.id = 'wa-pila';
    d.style.cssText =
      'position:fixed;bottom:2rem;right:2rem;z-index:50;display:flex;' +
      'flex-direction:column-reverse;align-items:flex-end;gap:.6rem';
    document.body.appendChild(d);
    return d;
  }

  function crearBoton(n) {
    var a = document.createElement('a');
    a.className = 'wa-boton';
    a.target = '_blank';
    a.rel = 'noopener';
    a.href = 'https://wa.me/' + n.numero;
    a.setAttribute('aria-label', n.etiqueta + ' por WhatsApp');
    a.innerHTML = icono() + '<span></span>';
    a.lastChild.textContent = n.etiqueta;          // textContent: la etiqueta es dato
    a.style.cssText =
      'display:inline-flex;align-items:center;gap:.5rem;padding:.7rem 1.05rem;' +
      'border-radius:9999px;background:#22c55e;color:#fff;text-decoration:none;' +
      'font-size:13px;font-weight:700;line-height:1;white-space:nowrap;' +
      'box-shadow:0 20px 25px -5px rgba(34,197,94,.4);' +
      'transition:transform .2s, background-color .2s';
    a.addEventListener('mouseenter', function () {
      a.style.background = '#16a34a';
      a.style.transform = 'translateY(-2px)';
    });
    a.addEventListener('mouseleave', function () {
      a.style.background = '#22c55e';
      a.style.transform = 'none';
    });
    return a;
  }

  // El botón propio de la aplicación vive dentro de app-home; se oculta para no
  // duplicar la atención por WhatsApp en la portada.
  function ocultarElDeLaApp() {
    var enlace = document.querySelector(SEL_WA_APP);
    var caja = enlace && enlace.closest('.fixed');
    if (caja && caja.id !== 'wa-pila') caja.style.display = 'none';
  }

  function revisarBoton() {
    ocultarElDeLaApp();
    if (!numeros.length) return;
    if (pila) return;                              // ya montada
    pila = crearPila();
    numeros.forEach(function (n) { pila.appendChild(crearBoton(n)); });
  }

  // El número y el usuario de Instagram salen de los mismos ajustes que usa la
  // aplicación, para que nada apunte a un sitio distinto del suyo.
  var usuarioIg = null;

  function cargarAjustes() {
    return fetch(raiz() + 'data/settings.json', { cache: 'no-cache' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (s) {
        var lista = (s && s.whatsapps) || [];
        if (!lista.length && s && s.whatsapp) {       // respaldo: configuración antigua
          lista = [{ numero: s.whatsapp, etiqueta: 'Escríbenos por WhatsApp' }];
        }
        numeros = lista
          .map(function (n) {
            return { numero: String(n.numero || '').replace(/[^0-9]/g, ''), etiqueta: n.etiqueta || 'WhatsApp' };
          })
          .filter(function (n) { return n.numero; });
        usuarioIg = ((s && s.instagram) || '').replace(/^@/, '').trim() || null;
      })
      .catch(function () { numeros = []; usuarioIg = null; });
  }

  // --- 2. «Solicitar cotización» con el producto puesto ---------------------

  var productos = null;

  function cargarProductos() {
    if (productos) return Promise.resolve(productos);
    return fetch(raiz() + 'data/products.json', { cache: 'no-cache' })
      .then(function (r) { return r.ok ? r.json() : []; })
      .then(function (p) { productos = Array.isArray(p) ? p : []; return productos; })
      .catch(function () { productos = []; return productos; });
  }

  function idDeLaFicha() {
    var m = location.pathname.match(/\/catalogo\/([^/?#]+)$/);
    return m ? decodeURIComponent(m[1]) : null;
  }

  function alCarrito(p) {
    var carrito = [];
    try { carrito = JSON.parse(localStorage.getItem(CLAVE_CARRITO) || '[]') || []; } catch (e) { carrito = []; }
    if (!Array.isArray(carrito)) carrito = [];

    var ya = carrito.filter(function (i) { return String(i.id) === String(p.id); })[0];
    if (ya) {
      ya.quantity = (ya.quantity || 1) + 1;
    } else {
      // La misma forma que guarda el carrito de la aplicación.
      carrito.push({
        id: p.id,
        name: p.name,
        price: Number(p.sale_price || p.price || 0),
        cover_image: p.cover_image,
        quantity: 1,
        sku: p.sku,
        brand: p.brand && p.brand.name
      });
    }
    try { localStorage.setItem(CLAVE_CARRITO, JSON.stringify(carrito)); } catch (e) { return false; }
    return true;
  }

  document.addEventListener('click', function (ev) {
    var a = ev.target && ev.target.closest && ev.target.closest('a[href]');
    if (!a) return;
    if (!/\/cotizacion\/?$/.test(a.getAttribute('href') || '')) return;
    if (a.closest('footer')) return;              // el enlace del pie es de navegación, no de un producto

    var id = idDeLaFicha();
    if (!id) return;                              // sólo desde la ficha de un producto

    ev.preventDefault();
    ev.stopPropagation();

    cargarProductos().then(function (lista) {
      var p = lista.filter(function (x) {
        return String(x.id) === id || String(x.slug) === id;
      })[0];
      if (p) alCarrito(p);
      // Recarga completa a propósito: el carrito se lee de localStorage al arrancar
      // la aplicación, así que una navegación interna no vería lo que acabamos de
      // guardar y el formulario volvería a salir vacío.
      location.assign(raiz() + 'cotizacion');
    });
  }, true);

  // --- 3. Buscador dentro del filtro de marcas ------------------------------

  var ID_BUSCADOR = 'filtro-marca-buscador';

  function sinTildes(t) {
    return (t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  }

  // Cuántos productos tiene cada marca. La aplicación no lo trae en /brands, así que
  // se cuenta sobre el catálogo ya horneado.
  //
  // La clave es el NOMBRE normalizado, no el slug: los radios del filtro llevan
  // value="on" porque Angular ata el valor al modelo y no al atributo del DOM, así
  // que desde fuera la única forma de saber a qué marca corresponde cada fila es su
  // texto. «Todas» es la excepción: esa sí trae value="".
  var conteos = null;
  function contarPorMarca(lista) {
    if (conteos) return conteos;
    conteos = {};
    lista.forEach(function (p) {
      var nombre = p.brand && p.brand.name;
      if (!nombre) return;
      var k = sinTildes(nombre);
      conteos[k] = (conteos[k] || 0) + 1;
    });
    return conteos;
  }

  function esTodas(label) {
    var input = label.querySelector('input');
    return sinTildes(label.textContent) === 'todas' || (input && input.value === '');
  }

  // El panel de filtros son bloques con un título y una lista .space-y-2 debajo.
  function bloqueDe(titulo) {
    var titulos = document.querySelectorAll('aside p, main p, div > p');
    for (var i = 0; i < titulos.length; i++) {
      var p = titulos[i];
      if (p.children.length === 0 && sinTildes(p.textContent) === sinTildes(titulo)) {
        var lista = p.parentElement && p.parentElement.querySelector('.space-y-2');
        if (lista) return { titulo: p, lista: lista, bloque: p.parentElement };
      }
    }
    return null;
  }

  function aplicarBusqueda(lista, texto) {
    var q = sinTildes(texto);
    var visibles = 0;
    [].forEach.call(lista.querySelectorAll('label'), function (l) {
      var todas = esTodas(l);                       // «Todas» no se filtra nunca
      var coincide = todas || !q || sinTildes(l.textContent).indexOf(q) !== -1;
      l.style.display = coincide ? '' : 'none';
      if (coincide && !todas) visibles++;
    });
    return visibles;
  }

  function montarBuscadorDeMarcas() {
    var b = bloqueDe('MARCA');
    if (!b) return;

    // Números de producto junto a cada marca.
    if (conteos) {
      [].forEach.call(b.lista.querySelectorAll('label'), function (l) {
        if (esTodas(l) || l.querySelector('.marca-conteo')) return;
        var n = conteos[sinTildes(l.textContent)];
        if (!n) return;
        var s = document.createElement('span');
        s.className = 'marca-conteo';
        s.textContent = n;
        s.style.cssText = 'margin-left:auto;font-size:11px;font-weight:700;color:#A08060';
        l.appendChild(s);
      });
    }

    if (document.getElementById(ID_BUSCADOR)) return;   // ya montado

    var caja = document.createElement('div');
    caja.style.cssText = 'margin-bottom:.6rem';

    var input = document.createElement('input');
    input.id = ID_BUSCADOR;
    input.type = 'search';
    input.placeholder = 'Buscar marca…';
    input.setAttribute('aria-label', 'Buscar marca');
    input.style.cssText =
      'width:100%;padding:.45rem .7rem;font-size:13px;color:#3B2A1A;' +
      'border:1px solid #E8DDD0;border-radius:.6rem;background:#fff;outline:none';
    input.addEventListener('focus', function () { input.style.borderColor = '#F36821'; });
    input.addEventListener('blur', function () { input.style.borderColor = '#E8DDD0'; });

    var vacio = document.createElement('p');
    vacio.textContent = 'Ninguna marca coincide.';
    vacio.style.cssText = 'display:none;font-size:12px;color:#A08060;margin:.5rem 0 0';

    input.addEventListener('input', function () {
      var n = aplicarBusqueda(b.lista, input.value);
      vacio.style.display = (input.value && n === 0) ? 'block' : 'none';
    });

    caja.appendChild(input);
    b.bloque.insertBefore(caja, b.lista);
    b.bloque.appendChild(vacio);

    compactar(b.lista, '17rem');
  }

  // Con 43 marcas la lista medía 1.251 px. Y por encima hay otras 29 categorías: sin
  // recortar las dos, el bloque de marcas queda a media página de scroll y el buscador
  // no sirve de nada. Recortarlas devuelve además el sentido al panel sticky, que
  // siendo más alto que la ventana no se quedaba fijo.
  function compactar(lista, alto) {
    if (!lista || lista.dataset.compacta) return;
    lista.dataset.compacta = '1';
    lista.style.maxHeight = alto;
    lista.style.overflowY = 'auto';
    lista.style.paddingRight = '.35rem';
  }

  function compactarCategorias() {
    var c = bloqueDe('CATEGORÍA');
    if (c) compactar(c.lista, '15rem');
  }

  // --- 4. Enlaces de Instagram ---------------------------------------------

  function urlInstagram() {
    return usuarioIg ? 'https://www.instagram.com/' + usuarioIg + '/' : null;
  }

  // La aplicación arma sus enlaces como instagram.com/<usuario>, sin www y sin barra
  // final. Se normalizan al perfil canónico para que todos apunten exactamente igual.
  function enlazarInstagram() {
    var url = urlInstagram();
    if (!url) return;

    [].forEach.call(document.querySelectorAll('a[href*="instagram.com"]'), function (a) {
      if (a.href === url) return;
      a.href = url;
      a.target = '_blank';
      a.rel = 'noopener';
    });

    // En el pie, la cuenta es texto suelto escrito en el propio bundle: nunca fue un
    // enlace. Se convierte en uno, conservando el icono que lo acompaña.
    var pie = document.querySelector('footer');
    if (!pie || pie.querySelector('.ig-pie')) return;

    var it = document.createTreeWalker(pie, NodeFilter.SHOW_TEXT);
    var nodo;
    while ((nodo = it.nextNode())) {
      if (!/@\s*agroforestal/i.test(nodo.nodeValue)) continue;
      if (nodo.parentElement.closest('a')) continue;      // ya estaba enlazado

      var a = document.createElement('a');
      a.className = 'ig-pie';
      a.href = url;
      a.target = '_blank';
      a.rel = 'noopener';
      a.textContent = '@' + usuarioIg;
      a.style.cssText = 'color:inherit;text-decoration:none';
      a.addEventListener('mouseenter', function () { a.style.textDecoration = 'underline'; });
      a.addEventListener('mouseleave', function () { a.style.textDecoration = 'none'; });
      nodo.parentNode.replaceChild(a, nodo);
      break;
    }
  }

  // --- 5. Red de seguridad para el logotipo ---------------------------------
  //
  // Si el archivo del logo no llega —no se subió, el servidor no lo sirve, una
  // extracción incompleta—, el navegador pinta el icono de imagen rota con el
  // texto alternativo al lado, que es peor que no tener logo. Aquí se intenta el
  // logo anterior y, si tampoco está, se oculta la imagen: la cabecera queda
  // limpia en vez de rota.
  //
  // Se escucha en fase de captura porque el evento `error` de una imagen no
  // burbujea, así que un listener normal en document nunca lo vería.

  var RESERVAS = [
    'storage/branding/7d29288d-ca9b-49f6-9968-64ee22913285.png',   // logo anterior
    'logo-agroforestal.svg'                                        // último recurso
  ];

  document.addEventListener('error', function (ev) {
    var img = ev.target;
    if (!img || img.tagName !== 'IMG') return;
    if (!/logo|branding/i.test(img.getAttribute('src') || '')) return;

    var intento = Number(img.dataset.reserva || 0);
    if (intento < RESERVAS.length) {
      img.dataset.reserva = intento + 1;
      img.src = raiz() + RESERVAS[intento];
    } else {
      img.style.display = 'none';
    }
  }, true);

  // --- arranque -------------------------------------------------------------

  function iniciar() {
    cargarProductos().then(function (lista) {
      contarPorMarca(lista);
      montarBuscadorDeMarcas();
      compactarCategorias();
    });
    cargarAjustes().then(function () {
      revisarBoton();
      enlazarInstagram();
      // El botón de la aplicación aparece y desaparece al cambiar de ruta. El
      // observador se dispara muchísimo en una SPA, así que se agrupa por fotograma.
      var pendiente = false;
      function revisarPronto() {
        if (pendiente) return;
        pendiente = true;
        requestAnimationFrame(function () {
          pendiente = false;
          revisarBoton();
          montarBuscadorDeMarcas();   // el catálogo se monta y desmonta al navegar
          compactarCategorias();
          enlazarInstagram();
        });
      }
      new MutationObserver(revisarPronto).observe(document.body, { childList: true, subtree: true });
      window.addEventListener('popstate', revisarPronto);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', iniciar);
  } else {
    iniciar();
  }
})();
